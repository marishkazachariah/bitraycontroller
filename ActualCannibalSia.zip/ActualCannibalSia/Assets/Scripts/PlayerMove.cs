﻿using UnityEngine;
using System.Collections;
using System.IO.Ports;

public class PlayerMove : MonoBehaviour {
	//pause menu
	public Transform canvas;
	public Transform Player;
	//player movement
	public float speed; 
	private float amountToMove;
	//shooting shit
	public Rigidbody projectile;
	public float bulletspeed = 20;
	//jumping
	private bool onGround;
	private float jumpPressure;
	private float minJump;
	private float maxJumpPressure;
	private Rigidbody rbody;
	//reset position
	Vector3 checkpoint; 


	//reading Arduino from serial port 
	SerialPort sp = new SerialPort("/dev/cu.usbserial-A104OF7B", 9600);

	void Start () {
		
		sp.Open();
		sp.ReadTimeout = 1;


		onGround = true;
		jumpPressure = 0f;
		minJump = 2f;
		maxJumpPressure = 10f;
		rbody = GetComponent<Rigidbody> ();

		checkpoint = new Vector3 (0, 0, 0);

	}

	// Update is called once per frame
	void Update () {
		amountToMove = speed * Time.deltaTime;

		if (sp.IsOpen) 
		{
			try
			{
				MoveObject(sp.ReadByte());
				print (sp.ReadByte());
			}
			catch(System.Exception)
			{

			}
		}

		/*
		//when using Arduino move the directional code to MoveObject 
		if (Input.GetKey(KeyCode.LeftArrow)) 
		{
			transform.Translate(Vector3.left * amountToMove, Space.World);
		}
		if (Input.GetKey(KeyCode.RightArrow))
		{
			transform.Translate(Vector3.right * amountToMove, Space.World);
		}
		if (Input.GetKey(KeyCode.UpArrow))
		{
			transform.Translate(Vector3.forward * amountToMove, Space.World);
		}
		if (Input.GetKey(KeyCode.DownArrow))
		{
			transform.Translate(Vector3.back * amountToMove, Space.World);
		}
		*/

	}

	void OnCollisionEnter(Collision other)
	{
		if (other.gameObject.CompareTag ("ground")) {
			onGround = true;
		}
		if (other.transform.tag == "Enemy"){
			transform.position = checkpoint; 
		}
	}


	//this is where joystick variables go
	void MoveObject(int direction)
	{
		if (direction == 1) 
		{
			transform.Translate(Vector3.left * amountToMove, Space.World);
		}
		if (direction == 2)
		{
			transform.Translate(Vector3.right * amountToMove, Space.World);
		}
		if (direction == 4)
		{
			transform.Translate(Vector3.forward * amountToMove, Space.World);
		}
		if (direction == 3)
		{
			transform.Translate(Vector3.back * amountToMove, Space.World);
		}
	
		if (direction == 8)
		{
			Rigidbody instantiatedProjectile = Instantiate(projectile,transform.position,transform.rotation)as Rigidbody;
			instantiatedProjectile.velocity = transform.TransformDirection(new Vector3(0, 0,speed));
		}

		if (direction == 7) {
			Pause ();
		}

		if (direction == 9) {
			Application.Quit ();
		}
		if (direction == 6) {
			Application.LoadLevel("Poop");
		}

	

		if (onGround) {
			//holding jump button
			if (direction == 5) {
				if (jumpPressure < maxJumpPressure) {
					jumpPressure += Time.deltaTime * 10f;
				} else {
					jumpPressure = maxJumpPressure;
				}
			}
			//not holding jump button
			else {
				//jump
				if (jumpPressure > 0f) 
				{
					jumpPressure = jumpPressure + minJump;
					rbody.velocity = new Vector3 (0f, jumpPressure, 0f);
					jumpPressure = 0f;
					onGround = true;
				}
			}
		}
	}

	public void Pause()
	{
		if (canvas.gameObject.activeInHierarchy == false) {
			canvas.gameObject.SetActive (true);
			Time.timeScale = 0;
	//		Player.GetComponent<PlayerMove> ().enabled = false;
		} else {
			canvas.gameObject.SetActive (false);
			Time.timeScale = 1;
	//		Player.GetComponent<PlayerMove> ().enabled = true;
		}
	}
}