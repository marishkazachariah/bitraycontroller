﻿using UnityEngine;
using System.Collections;
using System.IO.Ports;

public class ShootMe : MonoBehaviour
{
	public Rigidbody projectile;
	public float speed = 20;


	SerialPort sp = new SerialPort("/dev/cu.usbserial-A104OF7B", 9600);


	void Start() {
		sp.Open();
		sp.ReadTimeout = 1;
	}
	// Update is called once per frame
	void Update ()
	{

		if (sp.IsOpen) {
			try {
				Shooting (sp.ReadByte ());
				print (sp.ReadByte ());
			} catch (System.Exception) {

			}
		}
	}

	void Shooting(int shoot)
	{
		if (shoot == 8)
		{
			Rigidbody instantiatedProjectile = Instantiate(projectile,transform.position,transform.rotation)as Rigidbody;
			instantiatedProjectile.velocity = transform.TransformDirection(new Vector3(0, 0,speed));
		}
	}


}