﻿using UnityEngine;
using System.Collections;

public class FallDetect : MonoBehaviour {

	Vector3 checkpoint; 

	// Use this for initialization
	void Start () {
		checkpoint = new Vector3 (0, 0, 0);
	}

	// Update is called once per frame
	void Update () {
		if (transform.position.y < -8) {
			transform.position = checkpoint; 
		}

	}
}
